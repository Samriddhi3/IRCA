import { Are } from './are.model';

describe('Are', () => {
  it('should create an instance', () => {
    expect(new Are()).toBeTruthy();
  });
});
