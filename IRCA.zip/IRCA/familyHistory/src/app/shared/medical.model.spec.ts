import { Medical } from './medical.model';

describe('Medical', () => {
  it('should create an instance', () => {
    expect(new Medical()).toBeTruthy();
  });
});
