import { Details } from './details.model';

describe('Details', () => {
  it('should create an instance', () => {
    expect(new Details()).toBeTruthy();
  });
});
