export class Experience {
    
        checkbox9:boolean;
        checkbox10:boolean;
        checkbox11:boolean;
        checkbox12:boolean;
        checkbox13:boolean;
        checkbox14:boolean;
        checkbox15:boolean;
        checkbox16:boolean;
    
        constructor()
        {
            this.checkbox9=false;
            this.checkbox10=false;
            this.checkbox11=false;
            this.checkbox12=false;
            this.checkbox13=false;
            this.checkbox14=false;
            this.checkbox15=false;
            this.checkbox16=false;
        }
    }
    

