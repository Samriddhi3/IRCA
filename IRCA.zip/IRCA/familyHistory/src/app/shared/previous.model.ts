
export class Previous{
    _id: String;
    datebox:String;
    Sweatingw:Boolean;
    Palpitationw:Boolean;
    Tremorsw:Boolean;
    Insomniaw:Boolean;
    Fitsw:Boolean;
    Nauseaw:Boolean;
    Achesw:Boolean;
    Anxietyw:Boolean;
    Transientw:Boolean;
    Auditoryw:Boolean;

Haematemesisha:Boolean;
Jaundiceha:Boolean;
Headha:Boolean;
Seizureha:Boolean;
Abscessesha:Boolean;
Bleedingha:Boolean;
Skinha:Boolean;
Nerveha:Boolean;
Anyha:Boolean;
Noneha:Boolean;

Haematemesishr:Boolean;
Jaundicehr:Boolean;
Headhr:Boolean;
Seizurehr:Boolean;
Abscesseshr:Boolean;
Bleedinghr:Boolean;
Skinhr:Boolean;
Nervehr:Boolean;
Anyhr:Boolean;

Diabetesc:Boolean;
Liverc:Boolean;
Epilepsyc:Boolean;
Cardiacc:Boolean;
Infectionsc:Boolean;
Pulmonaryc:Boolean;
Chronic_bc:Boolean;
Chronic_ac:Boolean;
othersbox: String;

Seizureoa: Boolean;
Depressionoa: Boolean;
Suicidaloa: Boolean;
Confusionoa: Boolean;
Aggressiveoa: Boolean;
Hallucinationoa: Boolean;
Paranoiaoa: Boolean;
Noneoa: Boolean;

Seizureor: Boolean;
Depressionor: Boolean;
Suicidalor: Boolean;
Confusionor: Boolean;
Aggressiveor: Boolean;
Hallucinationor: Boolean;
Paranoiaor: Boolean;

Hist_of_prev_head: String;
Knowledge: String;
Type_of_drug: String;
Mention_who:String;

     constructor()
     {
      this._id = '';
      this.datebox='';
this.Sweatingw = false;
this.Palpitationw = false;
this.Tremorsw = false;
this.Insomniaw = false;
this.Fitsw = false;
this.Nauseaw = false;
this.Achesw = false;
this.Anxietyw = false;
this.Transientw = false;
this.Auditoryw = false;

this.Haematemesisha = false;
this.Jaundiceha = false;
this.Headha = false;
this.Seizureha = false;
this.Abscessesha = false;
this.Bleedingha = false;
this.Skinha = false;
this.Nerveha = false;
this.Anyha = false;
this.Noneha = false;

this.Haematemesishr = false;
this.Jaundicehr = false;
this.Headhr = false;
this.Seizurehr = false;
this.Abscesseshr = false;
this.Bleedinghr = false;
this.Skinhr = false;
this.Nervehr = false;
this.Anyhr = false;

this.Diabetesc = false;
this.Liverc = false;
this.Epilepsyc = false;
this.Cardiacc = false;
this.Infectionsc = false;
this.Pulmonaryc = false;
this.Chronic_bc = false;
this.Chronic_ac = false;
this.othersbox = '';

this.Seizureoa = false;
this.Depressionoa = false;
this.Suicidaloa = false;
this.Confusionoa = false;
this.Aggressiveoa = false;
this.Hallucinationoa = false;
this.Paranoiaoa = false;
this.Noneoa = false;

this.Seizureor = false;
this.Depressionor = false;
this.Suicidalor = false;
this.Confusionor = false;
this.Aggressiveor = false;
this.Hallucinationor = false;
this.Paranoiaor = false;

this.Hist_of_prev_head = '';
this.Knowledge = '';
this.Type_of_drug = '';
this.Mention_who = '';
          
     }
}
