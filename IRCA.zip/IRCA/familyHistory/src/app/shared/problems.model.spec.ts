import { Problems } from './problems.model';

describe('Problems', () => {
  it('should create an instance', () => {
    expect(new Problems()).toBeTruthy();
  });
});
