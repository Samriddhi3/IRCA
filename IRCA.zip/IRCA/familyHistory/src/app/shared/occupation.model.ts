export class Occupation {
    age:String;
    duration:String;
    special:String;
    check1:Boolean;
    check2:Boolean;
    check3:Boolean;
    check4:Boolean;
    reason:String

    constructor(){
        this.age="";
        this.duration="";
        this.special="";
        this.check1=false;
        this.check2=false;
        this.check3=false;
        this.check4=false;
        this.reason="";
    }
}
