import { Referral } from './referral.model';

describe('Referral', () => {
  it('should create an instance', () => {
    expect(new Referral()).toBeTruthy();
  });
});
