import { Legalhistory } from './legalhistory.model';

describe('Legalhistory', () => {
  it('should create an instance', () => {
    expect(new Legalhistory()).toBeTruthy();
  });
});
