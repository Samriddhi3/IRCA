
export class Activity {
    checkbox1: boolean;
    checkbox2: boolean;
    checkbox3: boolean;
    checkbox4: boolean;
    checkbox5: boolean;
    checkbox6: boolean;
    checkbox25: boolean;
    checkbox26: boolean;
    checkbox27: boolean;
    checkbox28: boolean;
    checkbox29: boolean;
    checkbox30: boolean;

  id: any;

    constructor() {
        this.checkbox1 = false;
        this.checkbox2 = false;
        this.checkbox3 = false;
        this.checkbox4 = false;
        this.checkbox5 = false;
        this.checkbox6 = false;
        this.checkbox25 = false;
        this.checkbox26 = false;
        this.checkbox27 = false;
        this.checkbox28 = false;
        this.checkbox29 = false;
        this.checkbox30 = false;

    }
}
