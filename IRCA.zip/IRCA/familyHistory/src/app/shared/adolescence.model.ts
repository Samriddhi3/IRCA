export class Adolescence {
    checkbox1:boolean;
    checkbox2:boolean;
    checkbox3:boolean;
    checkbox4:boolean;
    checkbox5:boolean;
    checkbox6:boolean;
    checkbox7:boolean;
    checkbox8:boolean;

    constructor()
    {
        this.checkbox1=false;
        this.checkbox2=false;
        this.checkbox3=false;
        this.checkbox4=false;
        this.checkbox5=false;
        this.checkbox6=false;
        this.checkbox7=false;
        this.checkbox8=false;
    }
}
