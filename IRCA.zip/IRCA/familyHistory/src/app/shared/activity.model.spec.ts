import { Activity } from './activity.model';

describe('Activity', () => {
  it('should create an instance', () => {
    expect(new Activity()).toBeTruthy();
  });
});
