import { Previous } from './previous.model';

describe('Previous', () => {
  it('should create an instance', () => {
    expect(new Previous()).toBeTruthy();
  });
});
