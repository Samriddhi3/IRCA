export class Comment {
        _id: string;
        mild: String;
        moderate: String;
        severe: String;
    
        constructor() {
            this._id = '';
            this.mild = '';
            this.moderate = '';
            this.severe = '';
        }
    
}
