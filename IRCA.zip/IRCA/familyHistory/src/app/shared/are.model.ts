export class Are {
    checkbox7: boolean;
    checkbox8: boolean;
    checkbox9: boolean;
    checkbox10: boolean;
    checkbox11: boolean;
    checkbox12: boolean;
    checkbox13: boolean;
    checkbox14: boolean;
    checkbox15: boolean;
    checkbox16: boolean;
    checkbox17: boolean;
    checkbox18: boolean;
    checkbox19: boolean;
    checkbox20: boolean;
    checkbox21: boolean;
    checkbox22: boolean;
    checkbox23: boolean;
    checkbox24: boolean;
    id: any;
  
    constructor() {
      this.checkbox7 = false;
      this.checkbox8 = false;
      this.checkbox9 = false;
      this.checkbox10 = false;
      this.checkbox11 = false;
      this.checkbox12 = false;
      this.checkbox13 = false;
      this.checkbox14 = false;
      this.checkbox15 = false;
      this.checkbox16 = false;
      this.checkbox17 = false;
      this.checkbox18 = false;
      this.checkbox19 = false;
      this.checkbox20 = false;
      this.checkbox21 = false;
      this.checkbox22 = false;
      this.checkbox23 = false;
      this.checkbox24 = false;
    }
  }
  
