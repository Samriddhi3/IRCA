export class Referral {
    _id: string;
   dateanddetails:String;
   actiontaken:string;
   referredto:string;
organisation:string;
   constructor() {
    this._id = '';
   this.dateanddetails='';
   this.actiontaken='';
   this.referredto='';
   this.organisation='';
}
}
