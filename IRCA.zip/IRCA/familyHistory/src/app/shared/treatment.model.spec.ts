import { Treatment } from './treatment.model';

describe('Treatment', () => {
  it('should create an instance', () => {
    expect(new Treatment()).toBeTruthy();
  });
});
